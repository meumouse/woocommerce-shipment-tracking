<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * View Order: Tracking information
 *
 * Shows tracking numbers view order page
 *
 * @author  WooThemes
 * @package WooCommerce Shipment Tracking/templates/myaccount
 * @version 1.6.4
 */

if ( $tracking_items ) : ?>

	<h2 class="my-account-tracking-title"><?php echo apply_filters( 'woocommerce_shipment_tracking_my_orders_title', __( 'Tracking Information', 'woocommerce-shipment-tracking' ) ); ?></h2>

	<table class="my-account-tracking">
		<thead>
			<tr>
				<th class="tracking-provider"><span class="nobr"><?php _e( 'Provider', 'woocommerce-shipment-tracking' ); ?></span></th>
				<th class="tracking-number"><span class="nobr"><?php _e( 'Tracking Number', 'woocommerce-shipment-tracking' ); ?></span></th>
				<th class="date-shipped"><span class="nobr"><?php _e( 'Date', 'woocommerce-shipment-tracking' ); ?></span></th>
				<th class="order-actions">&nbsp;</th>
			</tr>
		</thead>
		<tbody><?php
		foreach ( $tracking_items as $tracking_item ) {
				?><tr class="tracking">
					<td class="tracking-provider" data-title="<?php _e( 'Provider', 'woocommerce-shipment-tracking' ); ?>">
						<?php echo esc_html( $tracking_item['formatted_tracking_provider'] ); ?>
					</td>
					<td class="tracking-number" data-title="<?php _e( 'Tracking Number', 'woocommerce-shipment-tracking' ); ?>">
						<?php echo esc_html( $tracking_item['tracking_number'] ); ?>
					</td>
					<td class="date-shipped" data-title="<?php _e( 'Date', 'woocommerce-shipment-tracking' ); ?>" style="text-align:left; white-space:nowrap;">
						<time datetime="<?php echo date( wc_date_format(), $tracking_item['date_shipped'] ); ?>" title="<?php echo date( wc_date_format(), $tracking_item['date_shipped'] ); ?>"><?php echo date_i18n( get_option( 'date_format' ), $tracking_item['date_shipped'] ); ?></time>
					</td>
					<td class="order-actions" style="text-align: center;">
							<?php if ( '' !== $tracking_item['formatted_tracking_link'] ) { ?>
							<a href="<?php echo esc_url( $tracking_item['formatted_tracking_link'] ); ?>" target="_blank" class="track-button"><?php _e( 'Track', 'woocommerce-shipment-tracking' ); ?></a>
							<?php } ?>
					</td>
				</tr><?php
		}
		?></tbody>
	</table>

	<style type="text/css">
		table.my-account-tracking {
			width: 100%;
			border: 1px solid #e5e8ec;
			background-color: #fff;
			border-radius: 0.5rem;
			overflow: hidden;
			border-collapse: separate;
		}

		table.my-account-tracking th, table.my-account-tracking td {
			border: none;
			padding: 1rem;
		}

		h2.my-account-tracking-title {
			margin-top: 3rem;
			margin-bottom: 0.5rem;
			border-bottom: none;
		}

		table.my-account-tracking th, table.my-account-tracking td {
			border-right: 1px solid #e5e8ec;
		}

		table.my-account-tracking th:last-of-type, table.my-account-tracking td:last-of-type {
			border-right: 0;
		}

		table.my-account-tracking th {
			border-bottom: 1px solid #e5e8ec;
		}

		.track-button {
			display: inline-block;
			font-weight: 600;
			line-height: 1.6;
			color: #585c7b !important;
			text-align: center;
			text-decoration: none;
			white-space: nowrap;
			vertical-align: middle;
			cursor: pointer;
			user-select: none;
			background-color: transparent;
			border: 1px solid #e5e8ec;
			padding: 0.625rem 1.75rem;
			font-size: .875rem;
			border-radius: 0.375rem;
			transition: color 0.2s ease-in-out, background-color 0.2s ease-in-out, border-color 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
		}


		.track-button:hover {
			background-color: #eff2fc;
		}

		@media (max-width: 992px) {
			table.my-account-tracking {
				display: flex;
			}
			
			table.my-account-tracking tr {
				display: grid;
			}
			
			table.my-account-tracking td {
				border-right: none !important;
			}
			
			table.my-account-tracking th:last-of-type, 	table.my-account-tracking tr.tracking td:last-of-type {
				border-bottom: none;
			}
			
			table.my-account-tracking tr.tracking td {
				border-bottom: 1px solid #e5e8ec;
			}
			
			table.my-account-tracking td.order-actions {
				width: 200%;
				margin-left: -100%;
			}
			
			.track-button {
				width: 140px;
			}
		}
	</style>
<?php
endif;
